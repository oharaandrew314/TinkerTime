
=======================================

HotRockets

A replacement for engine particle FX

=======================================

Release 7

License:

http://creativecommons.org/licenses/by-nc-nd/3.0/


author: Nazari
contact: Nazari1382 on Official KerbalSpaceProgram.com forum 
also on reddit: Nazari1382

Updated 5/12/2014
Visual fixes for some SXT,RLA,and KSP trails

Updated 5/6/2014
Added support for AIES, SXT, RLA Stockalike and Ions, Kerbx, Nasa pack, and Procedural Parts SRB.
Improved Jet engine sound effects
Added experimental effect files for use with Real Solar System 

Updated 3/26/2014
Added KW solid rockets
Added support for Novapunch liquid engines and SRBs

Updated 3/24/2014
Compatibility fixes for newest Smokescreen plugin (included)
changes for flame length vs thrust on all rockets
Experimental "laggy launch" smoke on stock large SRB

Updated 3/13/2014
Support for Deadly Reentry and updated config file organization
Smokescreen FX tweaks
Support for KW Rocketry with new FX
Support for B9 Aerospace
Patch for B9 SABRE engines with Squad Rapier functionality

Updated 3/6/2014
First round of SmokeScreen plugin implementation
SmokeScreen is an enhanced FX plugin by Sarian. Thread:
http://forum.kerbalspaceprogram.com/threads/71630-0-23-SmokeScreen-Extended-FX-plugin

Updated 3/2/2014:
Minor visual changes to solid rocket and large liquid engine FX
New low power FX for engines like the Poodle
Extra FX files included for use with mod engines:
flamelowlarge,flamesrblarge,flamessme

Updated 1/14/2014:
ModuleManager support
More traditional flame graphic for standard 1.25 engines
small visual changes

Updated 1/12/2014:

Support for Aerospace engines
Tweaks of emitter speed
additional visual changes




Additional credits:
HotRockets includes ModuleManager 1.5.6, credit to ialdabaoth and sarbian
Thread: http://forum.kerbalspaceprogram.com/threads/55219
Andon - initial ModuleManager setup
