-----------------------------------------------------
-----------------------------------------------------
Radial Engine Mounts by PanaTee Structural Parts Co.
-----------------------------------------------------
-----------------------------------------------------
Developed by PandaHammer and TeeJaye85

--------
Version
--------
v0.30

-------------------------
Installation Instructions
-------------------------
Copy the contents of the GameData folder contained in the archive to the GameData folder in your KSP install directory.

-------------------------
CHANGELOG
-------------------------
v0.30 - 2014-09-07
- Updated licence
- Changed fictitious company name from PanaTee Structural Parts Co. to PanaTee Parts International (PPI)

v0.25 - 2014-08-31

- Added optional fuel capacity for Basic Radial Engine Mount (required Firespitter.dll)
- Tidied up collision mesh on Double Radial Engine Mount

v0.20 - 2014-08-30

- Updated texture for Basic Radial Engine Mount
- Scaled up raw models to avoid need for rescaleFactor
- Fine tuning of node locations to account for differences in stock part interface points
 

v0.15 - 2014-08-29

- Fixed issue where mounts did not appear in VAB staging interface.
- Corrected part name for basicRadialEngineMount (was missing the "Radial"!)
- Changed decoupling module from ModuleAnchoredDecoupler to ModuleDecouple
- Updated drag parameters -- values set to match Rockomax Mark 55 for double, nosecone for basic

v0.1 - 2014-08-28

- Initial beta release

-------
Licence
-------
Models, textures and all other assets of this modification are created by PandaHammer and TeeJaye85

This work is shared under Creative Commons Licence CC BY-NC-SA 4.0

PanaTee Parts International is a fictitious entity created for entertainment purposes.  It is in no way meant to represent a real entity.  Any similarity to a real entity is purely coincidental. (Thanks Thunder Aerospace Corporation for the inspiration)
